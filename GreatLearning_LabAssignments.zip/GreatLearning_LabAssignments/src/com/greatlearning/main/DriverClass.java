package com.greatlearning.main;

import java.util.Scanner;

import com.greatlearning.model.Employee;
import com.greatlearning.service.CredentialService;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String firstName, lastName, department;
		
		int choice=0;
		Scanner sc=new Scanner(System.in);
		
		
		do
		{
			System.out.println("\nPlease choose the Department:");
			System.out.println("1. Technical \n2. Admin \n3. Human Resource \n4. Legal \n5. Exit \n");
			choice=sc.nextInt();
			
			switch (choice) {
			case 1: { 
				System.out.print("Enter your First Name and Last Name: ");
				firstName=sc.next();
				lastName=sc.next();
				department="tech";
				Employee employee_obj=new Employee(firstName,lastName,department);
				
				break;
			}
			case 2:{
				System.out.print("Enter your First Name and Last Name: ");
				firstName=sc.next();
				lastName=sc.next();
				department="admin";
				Employee employee_obj=new Employee(firstName, lastName,department);
				
				break;
			}
			case 3: {
				System.out.print("Enter your First Name and Last Name: ");
				firstName=sc.next();
				lastName=sc.next();
				department="hr";
				Employee employee_obj=new Employee(firstName, lastName,department);
				
				break;
			}
			case 4:{
				System.out.print("Enter your First Name and Last Name: ");
				firstName=sc.next();
				lastName=sc.next();
				department="legal";
				Employee employee_obj=new Employee(firstName, lastName,department);
				
				break;
			}
			case 5:{
				System.out.println("Exiting...!!"); break;
				
			}
				
			
			default:
				throw new IllegalArgumentException("Unexpected value: " + choice);
			}
			
		}while(choice!=5);
		
		sc.close();
	}

}
