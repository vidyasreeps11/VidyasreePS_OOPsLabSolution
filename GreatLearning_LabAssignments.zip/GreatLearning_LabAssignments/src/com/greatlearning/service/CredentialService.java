package com.greatlearning.service;

import com.greatlearning.model.Employee;
import java.util.Random;

public class CredentialService {

	String fName,lName,dept,password,email;
	
	public CredentialService(String firstName, String lastName, String department) {
		// TODO Auto-generated constructor stub
		fName=firstName;
		lName=lastName;
		dept=department;
		
		password=generatePassword();
		email=generateEmailAddress();
		showCredentials();
		
	}

	
	
	String generatePassword()
	{
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*_=+.?";
		Random rnd = new Random();
		StringBuilder sb = new StringBuilder(10);
		for (int i = 0; i < 10; i++)
		password=	sb.append(characters.charAt(rnd.nextInt(characters.length()))).toString();
		
		return password;
	}
	
	String generateEmailAddress()
	{
		email=fName.trim().toLowerCase()+ lName.trim().toLowerCase()+"@"+dept+".softwaresolutions.com";
		
		return email;
	}
	
	void showCredentials()
	{
		System.out.println("\nHi "+fName+" "+lName+" please find your credentials below: ");
		System.out.println("\nEmail Address: "+email);
		System.out.println("Password: "+password);
	}
}
