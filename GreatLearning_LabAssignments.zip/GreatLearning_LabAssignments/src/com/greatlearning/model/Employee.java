package com.greatlearning.model;

import com.greatlearning.service.CredentialService;

public class Employee {
	
	String firstName, lastName, department;
	
	public Employee(String fName, String lName, String dept) {
		// TODO Auto-generated constructor stub
		
		firstName=fName;
		lastName=lName;
		department=dept;
		
		CredentialService credential_obj= new CredentialService(firstName, lastName, department);
	}

}
